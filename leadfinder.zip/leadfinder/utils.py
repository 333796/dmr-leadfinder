from __future__ import annotations

import threading
import time
from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")


class RateLimiter:
    """Thread-safe minimum interval limiter; capped at ten requests per second."""
    def __init__(self, requests_per_second: float = 10.0) -> None:
        if requests_per_second <= 0 or requests_per_second > 10:
            raise ValueError("requests_per_second must be between 0 and 10")
        self.interval = max(0.15, 1.0 / requests_per_second)
        self._lock = threading.Lock()
        self._next = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            delay = self._next - now
            if delay > 0:
                time.sleep(delay)
                now = time.monotonic()
            self._next = now + self.interval


def retry_call(fn: Callable[[], T], *, retries: int = 3, retryable: tuple[type[Exception], ...] = (TimeoutError,)) -> T:
    delay = 0.5
    for attempt in range(retries + 1):
        try:
            return fn()
        except retryable:
            if attempt >= retries:
                raise
            time.sleep(delay)
            delay = min(delay * 2, 8)
    raise RuntimeError("unreachable")
