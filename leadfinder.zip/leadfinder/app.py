from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Any

from .config import AppConfig
from .filters import passes_filters
from .models import Lead
from .scorer import score_company
from .sources.csv_source import CSVSource


def preview_csv(text: str, city: str = "Стерлитамак") -> dict[str, Any]:
    """Process an uploaded CSV in memory for the local web UI."""
    source = CSVSource("__uploaded__.csv")
    rows = list(csv.DictReader(io.StringIO(text)))
    companies = [source.normalize_company(row, row.get("category") or "Без категории", city) for row in rows]
    return process_companies(companies, min_rating=None, has_phone=False)


def process_companies(companies, *, min_rating: float | None, has_phone: bool) -> dict[str, Any]:
    seen: set[tuple[str, str, str]] = set()
    leads: list[Lead] = []
    for company in companies:
        key = (company.name.casefold(), company.address.casefold(), company.phone or "")
        if key in seen or not passes_filters(company, min_rating=min_rating, has_phone=has_phone):
            continue
        seen.add(key)
        leads.append(Lead(**company.model_dump(exclude={"raw"}), score=score_company(company), collected_at=""))
    leads.sort(key=lambda lead: lead.score, reverse=True)
    return {"leads": leads, "found": len(companies), "passed": len(leads)}


def lead_rows(leads: list[Lead]) -> list[dict[str, Any]]:
    return [lead.model_dump(exclude={"raw"}) for lead in leads]
