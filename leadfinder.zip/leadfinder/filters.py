from __future__ import annotations

from .models import Company


def is_website_missing(company: Company) -> bool:
    return not (company.website or "").strip()


def passes_filters(company: Company, *, min_rating: float | None = None, has_phone: bool = False) -> bool:
    if not is_website_missing(company):
        return False
    if min_rating is not None and (company.rating is None or company.rating < min_rating):
        return False
    if has_phone and not company.phone:
        return False
    return True
