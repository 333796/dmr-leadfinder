from __future__ import annotations

import os
from typing import Any

import requests

from ..models import Company
from ..normalizers import normalize_address, normalize_name, split_phones
from ..utils import RateLimiter
from .base import MissingAPIKeyError, QuotaExceededError, Source


class TwoGisSource(Source):
    name = "2gis"
    endpoint = "https://catalog.api.2gis.com/3.0/items"
    docs_url = "https://dev.2gis.com/"

    def __init__(self, *, requests_per_second: int = 10, session: requests.Session | None = None) -> None:
        from dotenv import load_dotenv
        load_dotenv()
        self.api_key = os.getenv("TWOGIS_API_KEY")
        if not self.api_key:
            raise MissingAPIKeyError(f"Не задан TWOGIS_API_KEY. Получите ключ: {self.docs_url}")
        self.session = session or requests.Session()
        self.limiter = RateLimiter(requests_per_second)
        self.request_count = 0

    def fetch(self, category: str, city: str, limit: int) -> list[Company]:
        result: list[Company] = []
        page = 1
        page_size = min(10, limit)
        while len(result) < limit:
            self.limiter.wait()
            params = {"key": self.api_key, "q": f"{category}, {city}", "type": "branch",
                      "has_site": "false", "fields": "items.contact_groups,items.reviews,items.full_address_name",
                      "page": page, "page_size": page_size}
            response = self.session.get(self.endpoint, params=params, timeout=30)
            self.request_count += 1
            if response.status_code in (403, 429):
                raise QuotaExceededError("2GIS API вернул 403/429: проверьте лицензию, квоту и доступность методов.")
            response.raise_for_status()
            payload = response.json()
            meta = payload.get("meta", {})
            if meta.get("code") in (403, 429):
                raise QuotaExceededError("2GIS API сообщает об ошибке доступа/квоты: проверьте тариф и права ключа.")
            if meta.get("code") == 404:
                break
            if meta.get("code", 200) != 200:
                raise ValueError(f"Ошибка каталога 2ГИС (код {meta['code']}).")
            items = payload.get("result", {}).get("items", [])
            if not items:
                break
            result.extend(self.normalize_company(item, category, city) for item in items)
            if len(items) < page_size or len(result) >= payload["result"].get("total", limit):
                break
            page += 1
        return result[:limit]

    def normalize_company(self, raw: dict[str, Any], category: str, city: str) -> Company:
        name, legal = normalize_name(raw.get("name"))
        groups = raw.get("contact_groups", [])
        phone_values, website, social = [], None, {}
        for group in groups:
            for contact in group.get("contacts", []):
                kind, value = contact.get("type", ""), contact.get("value", "")
                if kind == "phone": phone_values.append(value)
                elif kind in ("website", "url"): website = website or value
                elif kind in ("vkontakte", "vk"): social["vk"] = value
                elif kind in ("instagram", "telegram"): social[kind] = value
        phone, extra = split_phones(phone_values)
        address = raw.get("full_address_name") or raw.get("address_name") or ""
        reviews = raw.get("reviews", {})
        source_url = raw.get("share_url") or raw.get("url")
        if not source_url and raw.get("id"):
            source_url = f"https://2gis.ru/firm/{raw['id']}"
        # API returns review count using general_review_count, not general_count.
        reviews_count = reviews.get("general_review_count", reviews.get("general_count"))
        return Company(name=name, legal_name=legal, category=category, city=city, address=normalize_address(address, city), phone=phone, phone_extra=extra, website=website, vk=social.get("vk"), instagram=social.get("instagram"), telegram=social.get("telegram"), rating=reviews.get("general_rating"), reviews_count=reviews_count, source=self.name, source_url=source_url, raw=raw)
