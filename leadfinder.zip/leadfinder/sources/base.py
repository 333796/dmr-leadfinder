from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import Company


class MissingAPIKeyError(RuntimeError):
    pass


class QuotaExceededError(RuntimeError):
    pass


class Source(ABC):
    name: str

    @abstractmethod
    def fetch(self, category: str, city: str, limit: int) -> list[Company]: ...

    @abstractmethod
    def normalize_company(self, raw: dict, category: str, city: str) -> Company: ...
