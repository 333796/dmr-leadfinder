from __future__ import annotations

import os
from typing import Any

import requests

from ..models import Company
from ..normalizers import normalize_address, normalize_name, normalize_phone, split_phones
from ..utils import RateLimiter
from .base import MissingAPIKeyError, QuotaExceededError, Source


class YandexSource(Source):
    name = "yandex"
    endpoint = "https://search-maps.yandex.ru/v1/"
    docs_url = "https://yandex.ru/dev/maps/geosearch/"

    def __init__(self, *, requests_per_second: int = 10, session: requests.Session | None = None) -> None:
        self.api_key = os.getenv("YANDEX_API_KEY")
        if not self.api_key:
            raise MissingAPIKeyError(f"Не задан YANDEX_API_KEY. Получите ключ: {self.docs_url}")
        self.session = session or requests.Session()
        self.limiter = RateLimiter(requests_per_second)
        self.request_count = 0

    def fetch(self, category: str, city: str, limit: int) -> list[Company]:
        result: list[Company] = []
        page = 0
        while len(result) < limit:
            self.limiter.wait()
            params = {"apikey": self.api_key, "text": f"{category}, {city}", "lang": "ru_RU", "type": "biz", "results": min(50, limit - len(result)), "skip": page * 50}
            response = self.session.get(self.endpoint, params=params, timeout=30)
            self.request_count += 1
            if response.status_code in (403, 429):
                raise QuotaExceededError("Яндекс API вернул 403/429: квота или лимит запросов исчерпаны.")
            response.raise_for_status()
            payload = response.json()
            features = payload.get("features", [])
            if not features:
                break
            result.extend(self.normalize_company(item, category, city) for item in features)
            page += 1
        return result[:limit]

    def normalize_company(self, raw: dict[str, Any], category: str, city: str) -> Company:
        props = raw.get("properties", {})
        meta = props.get("CompanyMetaData", {})
        name, legal = normalize_name(meta.get("name") or props.get("name"))
        phones = [p.get("formatted", "") for p in meta.get("Phones", [])]
        phone, extra = split_phones(phones)
        address = meta.get("address") or props.get("description", "")
        card_url = f"https://yandex.ru/maps/org/{meta['id']}/" if meta.get("id") else None
        return Company(name=name, legal_name=legal, category=category, city=city, address=normalize_address(address, city), phone=phone, phone_extra=extra, website=meta.get("url") or None, rating=meta.get("rating", {}).get("rating"), reviews_count=meta.get("rating", {}).get("reviews"), source=self.name, source_url=card_url, raw=raw)
