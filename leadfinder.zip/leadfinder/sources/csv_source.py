from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from ..models import Company
from ..normalizers import normalize_address, normalize_name, normalize_phone, split_phones
from .base import Source


class CSVSource(Source):
    name = "csv"

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def fetch(self, category: str, city: str, limit: int) -> list[Company]:
        if not self.path.exists():
            raise FileNotFoundError(f"CSV-файл не найден: {self.path}")
        result = []
        with self.path.open("r", encoding="utf-8-sig", newline="") as stream:
            for row in csv.DictReader(stream):
                row_category = (row.get("category") or category).strip()
                if category and row_category.casefold() != category.casefold():
                    continue
                result.append(self.normalize_company(row, row_category, city))
                if len(result) >= limit:
                    break
        return result

    def normalize_company(self, raw: dict[str, Any], category: str, city: str) -> Company:
        name, legal = normalize_name(raw.get("name"))
        phones = [raw.get("phone", ""), raw.get("phone_extra", "")]
        phone, extra = split_phones(phones)
        return Company(
            name=name, legal_name=raw.get("legal_name") or legal,
            category=category, city=city,
            address=normalize_address(raw.get("address"), city),
            phone=phone, phone_extra=extra,
            vk=raw.get("vk"), instagram=raw.get("instagram"), telegram=raw.get("telegram"),
            website=raw.get("website") or None,
            rating=float(raw["rating"]) if raw.get("rating") not in (None, "") else None,
            reviews_count=int(raw["reviews_count"]) if raw.get("reviews_count") not in (None, "") else None,
            source="csv", source_url=raw.get("url") or raw.get("source_url"), raw=raw,
        )
