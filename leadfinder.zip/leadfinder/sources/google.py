from __future__ import annotations

import os
from typing import Any

import requests

from ..models import Company
from ..normalizers import normalize_address, normalize_name, split_phones
from ..utils import RateLimiter
from .base import MissingAPIKeyError, QuotaExceededError, Source


class GooglePlacesSource(Source):
    name = "google"
    endpoint = "https://places.googleapis.com/v1/places:searchText"
    docs_url = "https://developers.google.com/maps/documentation/places/web-service/text-search"

    def __init__(self, *, requests_per_second: int = 10, session: requests.Session | None = None) -> None:
        self.api_key = os.getenv("GOOGLE_PLACES_API_KEY")
        if not self.api_key:
            raise MissingAPIKeyError(f"Не задан GOOGLE_PLACES_API_KEY. Получите ключ: {self.docs_url}")
        self.session = session or requests.Session()
        self.limiter = RateLimiter(requests_per_second)
        self.request_count = 0

    def fetch(self, category: str, city: str, limit: int) -> list[Company]:
        result: list[Company] = []
        token = None
        while len(result) < limit:
            self.limiter.wait()
            headers = {"X-Goog-Api-Key": self.api_key, "X-Goog-FieldMask": "nextPageToken,places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.internationalPhoneNumber,places.websiteUri,places.rating,places.userRatingCount,places.googleMapsUri"}
            body: dict[str, Any] = {"textQuery": f"{category}, {city}", "pageSize": min(20, limit - len(result))}
            if token: body["pageToken"] = token
            response = self.session.post(self.endpoint, headers=headers, json=body, timeout=30)
            self.request_count += 1
            if response.status_code in (403, 429):
                raise QuotaExceededError("Google Places API вернул 403/429: проверьте API quota и billing.")
            response.raise_for_status()
            payload = response.json()
            places = payload.get("places", [])
            if not places: break
            result.extend(self.normalize_company(item, category, city) for item in places)
            token = payload.get("nextPageToken")
            if not token: break
        return result[:limit]

    def normalize_company(self, raw: dict[str, Any], category: str, city: str) -> Company:
        name, legal = normalize_name(raw.get("displayName", {}).get("text"))
        phone, extra = split_phones([raw.get("nationalPhoneNumber"), raw.get("internationalPhoneNumber")])
        return Company(name=name, legal_name=legal, category=category, city=city, address=normalize_address(raw.get("formattedAddress"), city), phone=phone, phone_extra=extra, website=raw.get("websiteUri"), rating=raw.get("rating"), reviews_count=raw.get("userRatingCount"), source=self.name, source_url=raw.get("googleMapsUri"), raw=raw)
