from __future__ import annotations

import argparse
import logging
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from tqdm import tqdm

from .config import AppConfig, load_config
from .exporter import export
from .filters import passes_filters
from .models import Lead
from .scorer import score_company
from .sources.base import MissingAPIKeyError, QuotaExceededError, Source
from .sources.csv_source import CSVSource

logger = logging.getLogger("leadfinder")


def _build_source(config: AppConfig) -> Source:
    if config.source == "csv":
        if not config.input_path:
            raise ValueError("Для source: csv задайте input_path в config.yaml или LEADFINDER_INPUT_PATH.")
        return CSVSource(config.input_path)
    if config.source == "yandex":
        from .sources.yandex import YandexSource
        return YandexSource(requests_per_second=config.rate_limit.requests_per_second)
    if config.source == "2gis":
        from .sources.twogis import TwoGisSource
        return TwoGisSource(requests_per_second=config.rate_limit.requests_per_second)
    from .sources.google import GooglePlacesSource
    return GooglePlacesSource(requests_per_second=config.rate_limit.requests_per_second)


def _dedupe_key(company) -> tuple[str, str, str]:
    return (company.name.casefold(), company.address.casefold(), company.phone or "")


def run(config: AppConfig) -> list[Path]:
    source = _build_source(config)
    all_companies = []
    for category in tqdm(config.categories, desc="Категории", unit="кат."):
        all_companies.extend(source.fetch(category, config.city, config.max_results_per_category))
    logger.info("Запросов: %s; найдено компаний: %s", getattr(source, "request_count", 0), len(all_companies))

    seen = set()
    leads = []
    collected_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for company in all_companies:
        key = _dedupe_key(company)
        if key in seen:
            continue
        seen.add(key)
        if not passes_filters(company, min_rating=config.min_rating, has_phone=config.has_phone):
            continue
        leads.append(Lead(**company.model_dump(exclude={"raw"}), score=score_company(company), collected_at=collected_at))
    leads.sort(key=lambda item: item.score, reverse=True)
    logger.info("Прошли фильтр: %s", len(leads))

    outputs: list[Path] = []
    base = Path(config.output.path)
    if config.output.split_by_category:
        for category in config.categories:
            safe = re.sub(r"[^\w-]+", "_", category, flags=re.UNICODE).strip("_") or "category"
            category_leads = [lead for lead in leads if lead.category == category]
            outputs.extend(export(category_leads, base.parent / f"{base.name}_{safe}", config.output.format))
    else:
        outputs.extend(export(leads, base, config.output.format))
    return outputs


def main() -> int:
    parser = argparse.ArgumentParser(description="Поиск бизнесов без сайта в публичных каталогах")
    parser.add_argument("--config", default="config.yaml", help="Путь к YAML-конфигурации")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        config = load_config(args.config)
        outputs = run(config)
        print("Файлы созданы:")
        for path in outputs:
            print(f"  {path}")
        return 0
    except (MissingAPIKeyError, QuotaExceededError, FileNotFoundError, ValueError) as exc:
        logger.error("%s", exc)
        return 2
    except Exception:
        logger.exception("Непредвиденная ошибка выполнения")
        return 1


if __name__ == "__main__":
    sys.exit(main())
