from __future__ import annotations

from typing import Any
from pydantic import BaseModel, ConfigDict, Field, field_validator


class Company(BaseModel):
    """A business entity and public business-directory contacts only."""
    model_config = ConfigDict(extra="ignore")

    name: str
    legal_name: str | None = None
    category: str
    city: str
    address: str = ""
    phone: str | None = None
    phone_extra: list[str] = Field(default_factory=list)
    vk: str | None = None
    instagram: str | None = None
    telegram: str | None = None
    website: str | None = None
    rating: float | None = None
    reviews_count: int | None = None
    source: str
    source_url: str | None = None
    raw: dict[str, Any] | None = Field(default=None, exclude=True)

    @field_validator("name", "category", "city", "address", mode="before")
    @classmethod
    def clean_text(cls, value: Any) -> str:
        return " ".join(str(value or "").split())


class Lead(Company):
    score: int = 0
    comment: str = ""
    collected_at: str
