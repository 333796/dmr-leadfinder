"""Leadfinder: ethical business lead discovery from official catalog APIs."""

__version__ = "1.0.0"
