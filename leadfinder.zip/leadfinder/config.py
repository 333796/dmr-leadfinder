from __future__ import annotations

import os
from pathlib import Path
from typing import Literal

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field, field_validator


class RateLimitConfig(BaseModel):
    requests_per_second: int = Field(default=10, ge=1, le=10)
    retry_on_429: bool = True
    max_retries: int = Field(default=3, ge=0, le=10)


class OutputConfig(BaseModel):
    format: Literal["csv", "xlsx", "both"] = "csv"
    path: str = "./output/leads"
    split_by_category: bool = False


class AppConfig(BaseModel):
    source: Literal["yandex", "2gis", "google", "csv"] = "csv"
    city: str = "Стерлитамак"
    categories: list[str] = Field(default_factory=list)
    max_results_per_category: int = Field(default=500, ge=1, le=5000)
    min_rating: float | None = Field(default=None, ge=0, le=5)
    has_phone: bool = False
    input_path: str | None = None
    output: OutputConfig = Field(default_factory=OutputConfig)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)

    @field_validator("categories")
    @classmethod
    def nonempty_categories(cls, values: list[str]) -> list[str]:
        return [v.strip() for v in values if v.strip()]


def load_config(path: str | Path) -> AppConfig:
    load_dotenv()
    config_path = Path(path)
    data: dict = {}
    if config_path.exists():
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if os.getenv("LEADFINDER_SOURCE"):
        data["source"] = os.environ["LEADFINDER_SOURCE"]
    if os.getenv("LEADFINDER_CITY"):
        data["city"] = os.environ["LEADFINDER_CITY"]
    if os.getenv("LEADFINDER_INPUT_PATH"):
        data["input_path"] = os.environ["LEADFINDER_INPUT_PATH"]
    return AppConfig.model_validate(data)
