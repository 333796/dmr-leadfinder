from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable

from .models import Lead

COLUMNS = ["score", "name", "category", "city", "address", "phone", "phone_extra", "vk", "instagram", "telegram", "rating", "reviews_count", "source", "source_url", "legal_name", "comment", "collected_at"]


def _record(lead: Lead) -> dict:
    data = lead.model_dump(exclude={"raw"})
    data["phone_extra"] = ";".join(data["phone_extra"])
    return {key: data.get(key, "") for key in COLUMNS}


def export(leads: Iterable[Lead], base_path: str | Path, fmt: str = "csv") -> list[Path]:
    leads = list(leads)
    rows = [_record(lead) for lead in leads]
    base = Path(base_path)
    base.parent.mkdir(parents=True, exist_ok=True)
    created = []
    if fmt in ("csv", "both"):
        path = base.with_suffix(".csv")
        with path.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=COLUMNS)
            writer.writeheader()
            writer.writerows(rows)
        created.append(path)
    if fmt in ("xlsx", "both"):
        from openpyxl import Workbook
        path = base.with_suffix(".xlsx")
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Leads"
        sheet.append(COLUMNS)
        for row in rows:
            sheet.append([row.get(col, "") for col in COLUMNS])
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        workbook.save(path)
        created.append(path)
    json_path = base.with_suffix(".json")
    json_path.write_text(json.dumps([lead.model_dump(mode="json") for lead in leads], ensure_ascii=False, indent=2), encoding="utf-8")
    created.append(json_path)
    return created
