from __future__ import annotations

import re

_LEGAL_PREFIX = re.compile(r"^\s*(?:(?:ООО|АО|ПАО|ЗАО|ИП|И\.П\.)\s*[«\"']?\s*)", re.IGNORECASE)
_DIGITS = re.compile(r"\D+")


def normalize_name(value: str | None) -> tuple[str, str | None]:
    original = " ".join((value or "").split())
    if not original:
        return "", None
    cleaned = _LEGAL_PREFIX.sub("", original).strip(" «»\"'")
    legal = original if cleaned != original else None
    return cleaned or original, legal


def normalize_phone(value: str | None) -> str | None:
    """Normalize Russian numbers to +7XXXXXXXXXX; keep foreign numbers untouched."""
    if not value:
        return None
    digits = _DIGITS.sub("", value)
    if len(digits) == 11 and digits[0] in "78":
        return "+7" + digits[1:]
    if len(digits) == 10:
        return "+7" + digits
    if value.strip().startswith("+") and 8 <= len(digits) <= 15:
        return "+" + digits
    return None


def normalize_address(value: str | None, city: str) -> str:
    address = " ".join((value or "").replace("ё", "е").split())
    if not address:
        return ""
    # Preserve source-provided detail while ensuring the configured locality is visible.
    if city.casefold() not in address.casefold():
        return f"{city}, {address.strip(' ,')}"
    return address


def split_phones(values: list[str | None] | None) -> tuple[str | None, list[str]]:
    normalized = []
    for item in values or []:
        if not item:
            continue
        for part in re.split(r"[,;/]", item):
            phone = normalize_phone(part)
            if phone and phone not in normalized:
                normalized.append(phone)
    return (normalized[0], normalized[1:]) if normalized else (None, [])
