from .models import Company


def score_company(company: Company) -> int:
    score = 0
    if company.phone:
        score += 30
    if company.address:
        score += 20
    score += 10 * sum(bool(v) for v in (company.vk, company.instagram, company.telegram))
    if company.rating is not None and company.rating >= 4:
        score += 15
    if company.reviews_count is not None and company.reviews_count >= 10:
        score += 10
    return min(score, 100)
